<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- As 3 meta tags acima *devem* vir em primeiro lugar dentro do `head`; qualquer outro conteúdo deve vir *após* essas tags -->
        <title>Controle Financeiro </title>

        <!-- Bootstrap -->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="css/estilo.css">
        <!-- HTML5 shim e Respond.js para suporte no IE8 de elementos HTML5 e media queries -->
        <!-- ALERTA: Respond.js não funciona se você visualizar uma página file:// -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body>
        <header>
            <nav class="navbar navbar-default sem-margem">
                <div class="container">
                    <div class="masthead">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navegacao" aria-expanded="false">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>

                        <h3 class="text-muted">Controle Financeiro</h3>
                        <nav>
                            <div class="collapse navbar-collapse" id="navegacao">
                                <ul class="nav navbar-nav text-uppercase ">
                                    <li><a href="#resumo" title="Resumo">Resumo</a></li>
                                    <li><a href="#dashboard" title="Dashboard">Dashboard</a></li>
                                    <li><a href="#configuracoes" title="Configurações">Configurações</a></li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>

            </nav>
        </header>    

        <div class="container ">
            <div class="row ">


                <section class="col-xs-6">
                    <h2 class="panel-title">Nova transação</h2>
                    <form method="get" action="#" >
                        <div class="form-group">
                            <label for="nome">Tipo de Transição</label>

                            <div class="input-group">
                                <div class="input-group-addon"><span class="glyphicon glyphicon-sort" aria-hidden="true"></span></div>
                                <select class="form-control" id="op" name="op">
                                    <option value="Compra">Compra</option>
                                    <option value="Venda">Venda</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="email">Nome da Mercadoria</label>
                            <div class="input-group">
                                <div class="input-group-addon"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></div>
                                <input type="text" name="n1" class="form-control" placeholder="Nome da mercadoria">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="tel">Valor</label>
                            <div class="input-group">
                                <div class="input-group-addon"><span class="glyphicon glyphicon-usd" aria-hidden="true"></span></div>
                                <input type="number" name="n2" class="form-control" placeholder="R$ 0,00">
                            </div>
                        </div>

                        <button type="submit" name="transacao" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal">
                            Adicionar transação
                        </button>
                        <button type="submit" name="listar" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal">
                            Listar transações
                            </button>
                    </form>
                </section>
                <section class="col-xs-6">
                    <div class="embed-responsive embed-responsive-4by3">
                        <h3 class="panel-title">Extrato de transações</h3>


                        <?php
                        if (isset($_GET["transacao"])) {
                            /* ... se os campos do formulário NÃO ESTIVEREM VAZIOS... */
                            if (!empty($_GET["op"]) && !empty($_GET["n1"]) &&
                                    !empty($_GET["n2"])) {
                                require_once ("conecta.php");

                                /* Usando a função mysqli_real_escape_string 
                                  Com esta função, strings que contenham caracteres especiais serão
                                  automaticamente tratadas minimizando as chances de acontecer um erro
                                  de SQL ou ataques via SQL injection */
                                $op = mysqli_real_escape_string($conexao, $_GET["op"]);
                                $n1 = mysqli_real_escape_string($conexao, $_GET["n1"]);
                                $n2 = mysqli_real_escape_string($conexao, $_GET["n2"]);

                                $sql = "INSERT INTO caixa (op, n1, n2) ";
                                $sql.= " VALUES('{$op}', '{$n1}', '{$n2}')";

                                mysqli_query($conexao, $sql) or die(mysqli_error($conexao));
							
                                require_once ("desconecta.php");
								//header('location: lista-de-entrada.php');
							
                            }
						}else if(isset($_GET["listar"])){
							require_once ("conecta.php");

							$sql = "SELECT * FROM caixa ORDER BY id";
							$resultado = mysqli_query($conexao, $sql) or die(mysqli_error($conexao));
							
							while ($dados = mysqli_fetch_assoc($resultado)) { ?>
								<table class="table table-striped ">
									<thead>
										<tr>
											<th scope="col">Nome da Mercadoria: </th>
											<th scope="col">Valor: R$ </th>
											<th scope="col">Tipo de Transição: </th>
										</tr>
									</thead>
									<tbody>
										<tr>
											<td><?= $dados["n1"] ?></td>
											<td><?= $dados["n2"] ?></td>
											<td><?= $dados["op"] ?></td>
										</tr>
									</tbody>
								</table>
								<?php
							}
							require_once ("desconecta.php");
						} else {
                            echo "<p>Você deve preencher todos os campos!</p>";
                        }
                        ?>



                    </div>
                </section>


            </div>

        </div>
    </div>
    <footer class="container-fluid">
    </footer>


    <!-- jQuery (obrigatório para plugins JavaScript do Bootstrap) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Inclui todos os plugins compilados (abaixo), ou inclua arquivos separadados se necessário -->
    <script src="js/bootstrap.min.js"></script>
</body>
</html>