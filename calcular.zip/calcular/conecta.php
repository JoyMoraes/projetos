<?php
$servidor = "localhost";
$usuario = "root";
$senha = "";
$banco = "caixa";

$conexao = mysqli_connect($servidor, $usuario, $senha, $banco);
mysqli_set_charset($conexao, "utf8");

if( mysqli_connect_errno($conexao) ){
    die("Erro ao conectar!" .mysqli_connect_error());
} 
?>