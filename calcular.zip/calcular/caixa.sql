# SQL para criar o banco
CREATE DATABASE caixa CHARACTER SET "utf8";

# SQL para criar a tabela
CREATE TABLE caixa (
    id SMALLINT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    op varchar(30) NOT NULL,
    n1 varchar(20) NOT NULL,
    n2 varchar(5) NOT NULL
);