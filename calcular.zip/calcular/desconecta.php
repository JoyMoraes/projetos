<?php
mysqli_close($conexao);
?>